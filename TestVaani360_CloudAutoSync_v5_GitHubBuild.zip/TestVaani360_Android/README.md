# TestVaani 360 — Production Android Project

Package: `com.testvaani360.app`
Version: `1.0.0` / versionCode `1`
Target/Compile SDK: `36`
Min SDK: `24`

## Included
- Current TestVaani 360 HTML app as Android asset
- Rajasthan CET, Patwari, SSC CGL, SSC CHSL, RAS/IAS
- Computer Gyan course and mock bank
- Easy English Speaking
- Results, bookmarks, mistakes, streak, milestones, performance
- WebView bridge for Google Play Billing and rewarded ads
- Play Billing 9.1.0 integration shell
- Release R8/minification configuration
- Portrait orientation and HTTPS-only network policy

## Premium product IDs
- `computer_gyan_27` — one-time product planned for ₹27
- `ssc_cgl_18m` — subscription planned for 18 months
- `ras_ias_18m` — subscription planned for 18 months

## Still requires the developer's real accounts
These cannot be honestly hard-coded or fabricated:
1. Google Play Console products/base plans and pricing
2. Real AdMob App ID/ad units
3. Firebase project + `google-services.json` if phone OTP/cloud sync is enabled
4. Trusted backend for purchase-token verification and entitlement
5. Release/upload signing key kept by the developer

Until those are configured, Premium stays locked and the app uses Google's test AdMob IDs. This prevents fake purchases or insecure client-only Premium unlocking.

## Build environment
AGP 9.4.0 requires Gradle 9.6.0 and JDK 17. Android SDK Platform 36 / Build Tools 36.0.0 should be installed.

Generate the Gradle wrapper in Android Studio or with a local Gradle 9.6 installation, then build:
`./gradlew assembleDebug`
`./gradlew bundleRelease`

For Play release, configure signing/Play App Signing in the developer's environment. Never put private signing keys, Firebase secrets, or server credentials in this repository.

## Build status

This project is source/build-ready, but the included source package does not contain the Android SDK or Gradle runtime. Build it with Android Studio or a machine/CI runner that has the Android SDK and Gradle available. Android officially documents SDK Build Tools as required for Android app builds.

The app now loads its bundled HTML through `WebViewAssetLoader` at `https://appassets.androidplatform.net/assets/index.html` instead of a direct `file://` URL, while keeping file and universal-file access disabled.


## Premium verification backend
The Android client now waits for server verification before acknowledgement/unlock. Configure the release build's `PREMIUM_API_URL` to the HTTPS backend URL. Do not place Google service-account credentials in the APK. The included `backend/` folder is a deployment scaffold; production should persist purchase tokens/entitlements and process Google Play Real-time Developer Notifications (RTDN).

## Account + cloud sync
Firebase-ready phone OTP and Firestore profile/progress sync have been added. See `FIREBASE_SETUP.md`. No fake Firebase project or credentials are embedded.


## Cloud Auto-Sync reliability (v2)
- Failed progress writes are queued locally and retried after login, app startup, and returning to the app.
- Only the latest pending progress snapshot is retained to avoid an unbounded queue.
- Successful cloud write clears the pending snapshot.
- Firestore rules scaffold is included in `firestore.rules`; deploy it only after reviewing the production Firebase project.
- Firebase configuration remains intentionally blank in source until a real Firebase project is connected.

## Phone-friendly APK build
This project includes `.github/workflows/build-apk.yml`. Upload the project to a GitHub repository, then open **Actions → Build TestVaani 360 APK → Run workflow**. After the build succeeds, download the `TestVaani360-debug-apk` artifact and install it on a test phone. This workflow is for testing only; do not treat the debug APK as the Play Store release build.
