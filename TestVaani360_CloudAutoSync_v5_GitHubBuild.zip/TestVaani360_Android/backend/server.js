import http from 'node:http';
import {GoogleAuth} from 'google-auth-library';

const PORT = Number(process.env.PORT || 8080);
const PACKAGE = process.env.PACKAGE_NAME || 'com.testvaani360.app';
const ALLOWED = new Set(['computer_gyan_27', 'ssc_cgl_18m', 'ras_ias_18m']);
const auth = new GoogleAuth({scopes: ['https://www.googleapis.com/auth/androidpublisher']});

function send(res, status, body) {
  const out = JSON.stringify(body);
  res.writeHead(status, {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store'});
  res.end(out);
}

async function googleGet(path) {
  const client = await auth.getClient();
  const token = await client.getAccessToken();
  const response = await fetch(`https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${encodeURIComponent(PACKAGE)}${path}`, {
    headers: {Authorization: `Bearer ${token.token}`}
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`Google Play API ${response.status}`);
  return data;
}

async function verify(productId, purchaseToken) {
  if (productId === 'computer_gyan_27') {
    const data = await googleGet(`/purchases/productsv2/tokens/${encodeURIComponent(purchaseToken)}`);
    const line = (data.productLineItem || []).find(x => x.productId === productId);
    return data.purchaseStateContext?.purchaseState === 'PURCHASED' && !!line;
  }
  const data = await googleGet(`/purchases/subscriptionsv2/tokens/${encodeURIComponent(purchaseToken)}`);
  const active = new Set(['SUBSCRIPTION_STATE_ACTIVE', 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD']);
  const line = (data.lineItems || []).some(x => x.productId === productId);
  return active.has(data.subscriptionState) && line;
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') return send(res, 200, {ok: true});
  if (req.method !== 'POST' || req.url !== '/v1/verify-purchase') return send(res, 404, {error: 'not_found'});
  try {
    let raw = '';
    for await (const chunk of req) raw += chunk;
    if (raw.length > 20000) return send(res, 413, {error: 'payload_too_large'});
    const body = JSON.parse(raw || '{}');
    const {packageName, productId, purchaseToken} = body;
    if (packageName !== PACKAGE || !ALLOWED.has(productId) || typeof purchaseToken !== 'string' || purchaseToken.length < 10) {
      return send(res, 400, {error: 'invalid_request'});
    }
    const entitled = await verify(productId, purchaseToken);
    return send(res, 200, {entitled, productId});
  } catch (e) {
    console.error(e);
    return send(res, 502, {error: 'verification_failed'});
  }
});
server.listen(PORT, () => console.log(`TestVaani 360 verifier listening on ${PORT}`));
