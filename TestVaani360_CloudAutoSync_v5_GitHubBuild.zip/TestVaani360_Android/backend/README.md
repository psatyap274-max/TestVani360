# TestVaani 360 Play purchase verifier

This backend verifies Google Play purchase tokens before the Android app grants Premium entitlement.

## Required environment
- `PACKAGE_NAME=com.testvaani360.app`
- `PORT=8080` (optional)
- Google service-account credentials available to `google-auth-library` (for example via `GOOGLE_APPLICATION_CREDENTIALS` in a server environment).

The service account must be granted the appropriate Play Console permissions for the Android Publisher API.

## Endpoints
- `GET /health`
- `POST /v1/verify-purchase`

Request:
```json
{"packageName":"com.testvaani360.app","productId":"computer_gyan_27","purchaseToken":"..."}
```

Response on a verified entitlement:
```json
{"entitled":true,"productId":"computer_gyan_27"}
```

Do **not** put the service-account JSON, private key, or Google API credentials inside the Android APK.

The Android app must have `PREMIUM_API_URL` set to the HTTPS URL of this service before release.
