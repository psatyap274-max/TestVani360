package com.testvaani360.app

import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import org.json.JSONObject
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class PremiumApi(private val baseUrl: String) {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun verify(productId: String, purchaseToken: String, callback: (Boolean, String, Boolean) -> Unit) {
        if (baseUrl.isBlank()) {
            main.post { callback(false, "Premium verification server अभी configure नहीं है।", false) }
            return
        }
        if (!baseUrl.startsWith("https://", ignoreCase = true)) {
            main.post { callback(false, "Premium verification server को HTTPS पर configure करें।", false) }
            return
        }
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(baseUrl.trimEnd('/') + "/v1/verify-purchase")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 10000
                    readTimeout = 10000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                val body = "{\"packageName\":\"com.testvaani360.app\",\"productId\":${json(productId)},\"purchaseToken\":${json(purchaseToken)}}"
                connection.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val json = runCatching { JSONObject(response) }.getOrNull()
                val granted = code in 200..299 && json?.optBoolean("entitled", false) == true
                main.post { callback(granted, if (granted) "Premium verified." else "Purchase verify नहीं हुआ।", code in 200..299) }
            } catch (e: Exception) {
                main.post { callback(false, "Verification server से connection नहीं हो पाया।", false) }
            } finally { connection?.disconnect() }
        }
    }

    private fun json(value: String): String = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
}
