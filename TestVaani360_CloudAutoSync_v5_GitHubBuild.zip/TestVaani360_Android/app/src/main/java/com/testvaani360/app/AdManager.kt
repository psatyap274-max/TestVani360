package com.testvaani360.app

import android.app.Activity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/** AdMob shell. Replace the test unit ID with a real unit only after Play/AdMob setup. */
class AdManager(private val activity: Activity) {
    companion object {
        // Official Google test rewarded-ad unit. Replace before production.
        const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"
    }

    private var rewardedAd: RewardedAd? = null

    fun loadRewarded() {
        RewardedAd.load(activity, TEST_REWARDED_ID, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { rewardedAd = null }
            })
    }

    fun showRewarded(onReward: (RewardItem) -> Unit, onUnavailable: () -> Unit = {}) {
        val ad = rewardedAd ?: run { onUnavailable(); return }
        ad.show(activity) { reward -> onReward(reward) }
        rewardedAd = null
        loadRewarded()
    }
}
