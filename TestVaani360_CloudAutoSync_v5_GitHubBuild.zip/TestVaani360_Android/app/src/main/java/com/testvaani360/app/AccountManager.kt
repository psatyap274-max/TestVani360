package com.testvaani360.app

import android.app.Activity
import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.android.gms.tasks.Tasks
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import java.util.concurrent.TimeUnit

class AccountManager(private val activity: Activity) {
    private val syncPrefs = activity.getSharedPreferences("cloud_sync_queue", Context.MODE_PRIVATE)
    private val pendingProgressKey = "pending_progress"

    private val configured: Boolean = BuildConfig.FIREBASE_API_KEY.isNotBlank() &&
        BuildConfig.FIREBASE_APP_ID.isNotBlank() && BuildConfig.FIREBASE_PROJECT_ID.isNotBlank()
    private var verificationId: String? = null
    private val auth: FirebaseAuth? by lazy {
        if (!configured) return@lazy null
        if (FirebaseApp.getApps(activity).isEmpty()) {
            FirebaseApp.initializeApp(activity, FirebaseOptions.Builder()
                .setApiKey(BuildConfig.FIREBASE_API_KEY)
                .setApplicationId(BuildConfig.FIREBASE_APP_ID)
                .setProjectId(BuildConfig.FIREBASE_PROJECT_ID)
                .setGcmSenderId(BuildConfig.FIREBASE_GCM_SENDER_ID)
                .build())
        }
        FirebaseAuth.getInstance()
    }
    private val db: FirebaseFirestore? by lazy { if (configured) FirebaseFirestore.getInstance() else null }

    fun available() = configured
    fun userId(): String? = auth?.currentUser?.uid
    fun phone(): String? = auth?.currentUser?.phoneNumber

    fun sendOtp(phone: String, callback: (Boolean, String) -> Unit) {
        val a = auth ?: return callback(false, "Firebase अभी configure नहीं है।")
        val options = PhoneAuthOptions.newBuilder(a)
            .setPhoneNumber(phone)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) = signIn(credential, callback)
                override fun onVerificationFailed(e: Exception) = callback(false, e.message ?: "OTP verification शुरू नहीं हो सका।")
                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                    verificationId = id
                    callback(true, "OTP भेज दिया गया है।")
                }
            }).build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun verifyOtp(code: String, callback: (Boolean, String) -> Unit) {
        val id = verificationId ?: return callback(false, "पहले OTP भेजें।")
        signIn(PhoneAuthProvider.getCredential(id, code), callback)
    }

    private fun signIn(credential: PhoneAuthCredential, callback: (Boolean, String) -> Unit) {
        auth?.signInWithCredential(credential)?.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                retryPendingProgress()
                callback(true, "Login सफल हुआ।")
            } else callback(false, task.exception?.message ?: "Login नहीं हो सका।")
        } ?: callback(false, "Firebase उपलब्ध नहीं है।")
    }

    fun saveProfile(name: String, goal: String, callback: (Boolean, String) -> Unit) {
        val uid = userId() ?: return callback(false, "पहले login करें।")
        db?.collection("users")?.document(uid)?.set(mapOf(
            "name" to name.take(40), "goal" to goal.take(50),
            "phone" to (phone() ?: ""), "updatedAt" to System.currentTimeMillis()
        ))?.addOnSuccessListener { callback(true, "Profile sync हो गया।") }
            ?.addOnFailureListener { callback(false, "Profile sync नहीं हो सका।") }
            ?: callback(false, "Firebase उपलब्ध नहीं है।")
    }

    fun loadProfile(callback: (Map<String, Any>?) -> Unit) {
        val uid = userId() ?: return callback(null)
        db?.collection("users")?.document(uid)?.get()
            ?.addOnSuccessListener { callback(it.data) }
            ?.addOnFailureListener { callback(null) }
            ?: callback(null)
    }

    fun saveProgress(progressJson: String, callback: (Boolean) -> Unit) {
        val clean = progressJson.take(500000)
        val uid = userId()
        if (uid == null || db == null) {
            syncPrefs.edit().putString(pendingProgressKey, clean).apply()
            return callback(false)
        }
        db!!.collection("users").document(uid).collection("app").document("progress")
            .set(mapOf("data" to clean, "updatedAt" to System.currentTimeMillis()))
            .addOnSuccessListener {
                syncPrefs.edit().remove(pendingProgressKey).apply()
                callback(true)
            }
            .addOnFailureListener {
                syncPrefs.edit().putString(pendingProgressKey, clean).apply()
                callback(false)
            }
    }

    fun retryPendingProgress(callback: (Boolean) -> Unit = {}) {
        val pending = syncPrefs.getString(pendingProgressKey, null) ?: return callback(true)
        val uid = userId()
        val firestore = db
        if (uid == null || firestore == null) return callback(false)
        firestore.collection("users").document(uid).collection("app").document("progress")
            .set(mapOf("data" to pending, "updatedAt" to System.currentTimeMillis()))
            .addOnSuccessListener {
                syncPrefs.edit().remove(pendingProgressKey).apply()
                callback(true)
            }
            .addOnFailureListener { callback(false) }
    }

    fun hasPendingSync(): Boolean = syncPrefs.contains(pendingProgressKey)

    fun loadProgress(callback: (String?) -> Unit) {
        val uid = userId() ?: return callback(null)
        db?.collection("users")?.document(uid)?.collection("app")?.document("progress")?.get()
            ?.addOnSuccessListener { callback(it.getString("data")) }
            ?.addOnFailureListener { callback(null) }
            ?: callback(null)
    }

    fun deleteAccountAndData(callback: (Boolean, String) -> Unit) {
        val currentUser = auth?.currentUser
        val firestore = db
        if (currentUser == null || firestore == null) {
            syncPrefs.edit().clear().apply()
            return callback(false, "पहले Mobile OTP से login करें।")
        }
        val uid = currentUser.uid
        val profileDelete = firestore.collection("users").document(uid).delete()
        val progressDelete = firestore.collection("users").document(uid)
            .collection("app").document("progress").delete()
        Tasks.whenAllComplete(profileDelete, progressDelete).addOnCompleteListener { deleteTasks ->
            val failed = deleteTasks.result?.any { !it.isSuccessful } == true
            if (failed) {
                callback(false, "Account data पूरी तरह delete नहीं हो पाया। कृपया फिर कोशिश करें।")
                return@addOnCompleteListener
            }
            currentUser.delete().addOnCompleteListener { authTask ->
                syncPrefs.edit().clear().apply()
                if (authTask.isSuccessful) {
                    verificationId = null
                    callback(true, "Account और cloud data delete हो गया।")
                } else {
                    callback(false, "Cloud data delete हो गया, लेकिन account delete पूरा नहीं हुआ। दोबारा login करके फिर कोशिश करें।")
                }
            }
        }
    }

    fun signOut() = auth?.signOut()
}
