package com.testvaani360.app

import android.app.Activity
import com.android.billingclient.api.*

class BillingManager(
    private val activity: Activity,
    private val onPurchaseForVerification: (productId: String, purchaseToken: String, isSubscription: Boolean) -> Unit,
    private val onMessage: (String) -> Unit
) : PurchasesUpdatedListener {
    companion object {
        const val COMPUTER_GYAN_27 = "computer_gyan_27"
        const val SSC_CGL_18M = "ssc_cgl_18m"
        const val RAS_IAS_18M = "ras_ias_18m"
        val PRODUCT_IDS = setOf(COMPUTER_GYAN_27, SSC_CGL_18M, RAS_IAS_18M)
    }

    private val billingClient = BillingClient.newBuilder(activity)
        .setListener(this)
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
        )
        .enableAutoServiceReconnection()
        .build()

    fun connect() {
        if (billingClient.isReady) { queryExistingPurchases(); return }
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) queryExistingPurchases()
                else onMessage("Google Play Billing अभी उपलब्ध नहीं है।")
            }
            override fun onBillingServiceDisconnected() { onMessage("Billing connection अस्थायी रूप से बंद है।") }
        })
    }

    fun buy(productId: String) {
        if (productId !in PRODUCT_IDS) { onMessage("Invalid Premium product."); return }
        if (!billingClient.isReady) { onMessage("Billing अभी तैयार नहीं है।"); connect(); return }
        val query = QueryProductDetailsParams.newBuilder().setProductList(listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(if (productId == COMPUTER_GYAN_27) BillingClient.ProductType.INAPP else BillingClient.ProductType.SUBS)
                .build()
        )).build()
        billingClient.queryProductDetailsAsync(query) { result, detailsResult ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                onMessage("Premium plan अभी Google Play पर उपलब्ध नहीं है।")
                return@queryProductDetailsAsync
            }
            val product = detailsResult.productDetailsList.firstOrNull()
            if (product == null) {
                onMessage("इस Premium plan का Play product अभी उपलब्ध नहीं है।")
                return@queryProductDetailsAsync
            }
            val productParamsBuilder = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(product)
            if (productId != COMPUTER_GYAN_27) {
                val offer = product.subscriptionOfferDetails?.firstOrNull()
                if (offer == null) { onMessage("इस subscription का Play offer अभी उपलब्ध नहीं है।"); return@queryProductDetailsAsync }
                productParamsBuilder.setOfferToken(offer.offerToken)
            }
            billingClient.launchBillingFlow(activity, BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(listOf(productParamsBuilder.build())).build())
        }
    }

    fun restore() {
        if (!billingClient.isReady) { connect(); return }
        queryPurchases(BillingClient.ProductType.SUBS)
        queryPurchases(BillingClient.ProductType.INAPP)
    }

    private fun queryExistingPurchases() = restore()

    private fun queryPurchases(type: String) {
        val params = QueryPurchasesParams.newBuilder().setProductType(type).build()
        billingClient.queryPurchasesAsync(params) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) purchases.forEach { handlePurchase(it, type == BillingClient.ProductType.SUBS) }
        }
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        when {
            result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null ->
                purchases.forEach { handlePurchase(it, it.products.any { id -> id != COMPUTER_GYAN_27 }) }
            result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED -> onMessage("Purchase पूरा नहीं हो सका।")
        }
    }

    private fun handlePurchase(purchase: Purchase, isSubscription: Boolean) {
        if (purchase.purchaseState == Purchase.PurchaseState.PENDING) {
            onMessage("Payment pending है। Payment पूरा होने के बाद Premium verify होगा।")
            return
        }
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return
        val productId = purchase.products.firstOrNull() ?: return
        if (productId !in PRODUCT_IDS) return

        // Do NOT grant entitlement or acknowledge here. The backend must first
        // verify this purchaseToken with Google Play Developer API.
        onPurchaseForVerification(productId, purchase.purchaseToken, isSubscription)
    }

    fun acknowledgeVerifiedPurchase(purchaseToken: String, onDone: (Boolean) -> Unit) {
        billingClient.acknowledgePurchase(
            AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchaseToken).build()
        ) { result -> onDone(result.responseCode == BillingClient.BillingResponseCode.OK) }
    }

    fun close() = billingClient.endConnection()
}
