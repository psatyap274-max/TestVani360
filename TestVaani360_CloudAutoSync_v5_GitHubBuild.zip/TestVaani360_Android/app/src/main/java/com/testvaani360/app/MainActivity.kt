package com.testvaani360.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var billingManager: BillingManager
    private lateinit var adManager: AdManager
    private lateinit var premiumApi: PremiumApi
    private lateinit var accountManager: AccountManager
    private val premiumPrefs by lazy { getSharedPreferences("premium_entitlements", MODE_PRIVATE) }
    private val premiumTokenPrefs by lazy { getSharedPreferences("premium_tokens", MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MobileAds.initialize(this) {}
        premiumApi = PremiumApi(BuildConfig.PREMIUM_API_URL)
        accountManager = AccountManager(this)
        adManager = AdManager(this).also { it.loadRewarded() }

        webView = findViewById(R.id.webView)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.setSupportZoom(false)
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        billingManager = BillingManager(
            activity = this,
            onPurchaseForVerification = { productId, purchaseToken, isSubscription ->
                premiumApi.verify(productId, purchaseToken) { entitled, message, definitive ->
                    if (!entitled) {
                        if (definitive) {
                            premiumPrefs.edit().putBoolean(productId, false).apply()
                            premiumTokenPrefs.edit().remove(productId).apply()
                        }
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                        return@verify
                    }
                    billingManager.acknowledgeVerifiedPurchase(purchaseToken) { acknowledged ->
                        runOnUiThread {
                            if (!acknowledged) {
                                Toast.makeText(this, "Purchase verify हुआ, लेकिन acknowledgement पूरा नहीं हुआ।", Toast.LENGTH_LONG).show()
                                return@runOnUiThread
                            }
                            premiumPrefs.edit().putBoolean(productId, true).apply()
                            premiumTokenPrefs.edit().putString(productId, purchaseToken).apply()
                            webView.evaluateJavascript(
                                "window.onNativePremiumVerified && window.onNativePremiumVerified(${org.json.JSONObject.quote(productId)});",
                                null
                            )
                            Toast.makeText(this, "Premium verified और unlock हो गया।", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            },
            onMessage = { message -> runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() } }
        )

        webView.addJavascriptInterface(NativeBridge(), "TestVaaniNative")
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        billingManager.connect()
        revalidateStoredPremiums()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    inner class NativeBridge {
        @JavascriptInterface fun accountAvailable(): Boolean = accountManager.available()
        @JavascriptInterface fun accountUserId(): String = accountManager.userId() ?: ""
        @JavascriptInterface fun accountPhone(): String = accountManager.phone() ?: ""
        @JavascriptInterface fun sendOtp(phone: String) = runOnUiThread {
            accountManager.sendOtp(phone) { ok, message ->
                runOnUiThread { webView.evaluateJavascript("window.onNativeOtpResult && window.onNativeOtpResult(${ok}, ${org.json.JSONObject.quote(message)});", null) }
            }
        }
        @JavascriptInterface fun verifyOtp(code: String) = runOnUiThread {
            accountManager.verifyOtp(code) { ok, message ->
                runOnUiThread { webView.evaluateJavascript("window.onNativeLoginResult && window.onNativeLoginResult(${ok}, ${org.json.JSONObject.quote(message)});", null) }
            }
        }
        @JavascriptInterface fun saveCloudProfile(name: String, goal: String) = runOnUiThread {
            accountManager.saveProfile(name, goal) { ok, message ->
                runOnUiThread { webView.evaluateJavascript("window.onNativeCloudResult && window.onNativeCloudResult(${ok}, ${org.json.JSONObject.quote(message)});", null) }
            }
        }
        @JavascriptInterface fun loadCloudProfile() = runOnUiThread {
            accountManager.loadProfile { data ->
                val json = org.json.JSONObject(data ?: emptyMap<String, Any>()).toString()
                runOnUiThread { webView.evaluateJavascript("window.onNativeProfileLoaded && window.onNativeProfileLoaded(${org.json.JSONObject.quote(json)});", null) }
            }
        }
        @JavascriptInterface fun saveCloudProgress(progressJson: String) = runOnUiThread {
            accountManager.saveProgress(progressJson) { ok ->
                webView.evaluateJavascript("window.onNativeSyncStatus && window.onNativeSyncStatus(${ok}, ${accountManager.hasPendingSync()});", null)
            }
        }
        @JavascriptInterface fun retryCloudSync() = runOnUiThread {
            accountManager.retryPendingProgress { ok ->
                webView.evaluateJavascript("window.onNativeSyncStatus && window.onNativeSyncStatus(${ok}, ${accountManager.hasPendingSync()});", null)
            }
        }
        @JavascriptInterface fun loadCloudProgress() = runOnUiThread {
            accountManager.loadProgress { data ->
                if (data != null) webView.evaluateJavascript("window.onNativeProgressLoaded && window.onNativeProgressLoaded(${org.json.JSONObject.quote(data)});", null)
            }
        }
        @JavascriptInterface fun logout() = runOnUiThread {
            accountManager.signOut()
            clearLocalUserData()
            webView.evaluateJavascript("window.onNativeLoginResult && window.onNativeLoginResult(true, 'Logout हो गया।');", null)
        }

        @JavascriptInterface fun deleteAccount() = runOnUiThread {
            accountManager.deleteAccountAndData { ok, message ->
                runOnUiThread {
                    if (ok) clearLocalUserData()
                    webView.evaluateJavascript("window.onNativeAccountDeletionResult && window.onNativeAccountDeletionResult(${ok}, ${org.json.JSONObject.quote(message)});", null)
                }
            }
        }

        @JavascriptInterface fun buy(productId: String) = runOnUiThread { billingManager.buy(productId) }
        @JavascriptInterface fun restore() = runOnUiThread { billingManager.restore() }
        @JavascriptInterface fun isPremiumUnlocked(productId: String): Boolean =
            premiumPrefs.getBoolean(productId, false)
        @JavascriptInterface fun rewarded() = runOnUiThread {
            adManager.showRewarded(
                onReward = { reward -> Toast.makeText(this@MainActivity, "Reward: ${reward.amount} ${reward.type}", Toast.LENGTH_SHORT).show() },
                onUnavailable = { Toast.makeText(this@MainActivity, "Rewarded ad अभी उपलब्ध नहीं है।", Toast.LENGTH_SHORT).show() }
            )
        }
    }

    private fun revalidateStoredPremiums() {
        val ids = listOf(BillingManager.COMPUTER_GYAN_27, BillingManager.SSC_CGL_18M, BillingManager.RAS_IAS_18M)
        ids.forEach { productId ->
            val token = premiumTokenPrefs.getString(productId, null) ?: return@forEach
            premiumApi.verify(productId, token) { entitled, _, definitive ->
                if (definitive && !entitled) {
                    premiumPrefs.edit().putBoolean(productId, false).apply()
                    premiumTokenPrefs.edit().remove(productId).apply()
                    runOnUiThread {
                        webView.evaluateJavascript(
                            "window.onNativePremiumRevoked && window.onNativePremiumRevoked(${org.json.JSONObject.quote(productId)});",
                            null
                        )
                    }
                }
            }
        }
    }

    private fun clearLocalUserData() {
        premiumPrefs.edit().clear().apply()
        premiumTokenPrefs.edit().clear().apply()
        webView.evaluateJavascript("try{localStorage.clear();sessionStorage.clear();}catch(e){}", null)
    }

    override fun onDestroy() {
        if (::billingManager.isInitialized) billingManager.close()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
