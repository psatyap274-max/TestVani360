# TestVaani 360 release rules
-keep class com.android.billingclient.** { *; }
-keep class com.google.android.gms.ads.** { *; }
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
