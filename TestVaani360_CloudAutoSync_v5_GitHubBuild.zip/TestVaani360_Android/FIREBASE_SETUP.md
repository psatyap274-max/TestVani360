# Firebase account + cloud sync setup

This project now contains a Firebase-ready phone OTP account layer and Firestore profile/progress sync. It is intentionally disabled until the developer connects a real Firebase project.

Official Firebase Android phone-auth guidance requires enabling Phone sign-in and configuring app verification/SHA fingerprints in Firebase Console. See: https://firebase.google.com/docs/auth/android/phone-auth

## Required values
Set these BuildConfig values in `app/build.gradle.kts` for the release build:
- `FIREBASE_API_KEY`
- `FIREBASE_APP_ID`
- `FIREBASE_PROJECT_ID`
- `FIREBASE_GCM_SENDER_ID`

Then in Firebase Console:
1. Add Android app package `com.testvaani360.app`.
2. Add the release SHA-1 and SHA-256 fingerprints.
3. Enable Authentication → Phone.
4. Set an appropriate SMS region policy.
5. Create Cloud Firestore.
6. Add production Firestore Security Rules so each user can read/write only their own `/users/{uid}` document and `/users/{uid}/app/progress` document.

Do not put Google service-account credentials in the Android app.

## What is already wired
- Mobile OTP request and verification callbacks.
- Firebase user UID and phone access from the WebView bridge.
- Profile cloud save/load.
- Progress JSON cloud save/load hooks.
- Graceful message when Firebase is not configured.

The actual Firebase project cannot be invented or activated from source code alone; it requires the developer's Firebase project configuration.
